import pandas as pd

def load_movies(filename):
    return pd.read_csv(filename)

def get_genres(movie_title, df):
    movie = df[df['title'].str.lower() == movie_title.lower()]
    if movie.empty:
        return None
    return set(movie.iloc[0]['genres'].lower().split(", "))

def recommend_movies(movie_title, df):
    input_genres = get_genres(movie_title, df)
    if input_genres is None:
        return f"Movie '{movie_title}' not found in the database."

    recommendations = []
    for _, row in df.iterrows():
        if row['title'].lower() == movie_title.lower():
            continue
        genres = set(row['genres'].lower().split(", "))
        score = len(input_genres & genres)
        if score > 0:
            recommendations.append((row['title'], score))

    recommendations.sort(key=lambda x: x[1], reverse=True)
    return [title for title, _ in recommendations]

if __name__ == "__main__":
    movies_df = load_movies("movies.csv")
    movie_name = input("Enter a movie name: ")
    results = recommend_movies(movie_name, movies_df)

    if isinstance(results, str):
        print(results)
    else:
        print("\nRecommended Movies:")
        for movie in results:
            print("-", movie)
