# Movie Recommendation System 🎬

A simple movie recommendation system based on genre similarity.

## 💡 Project Description

This project provides recommendations for movies based on user input and movie genres using basic statistics and CSV file operations.

## 🛠️ Technologies Used

- Python
- Pandas
- CSV
- Basic Statistics
- Excel (for data entry or preprocessing)

## 📁 Files

- `movies.csv`: Contains sample movie data with genres.
- `recommender.py`: Python script that loads movie data and recommends similar movies based on genres.

## ▶️ How to Use

1. Clone the repository or download the files.
2. Ensure you have Python installed.
3. Run the script:

```bash
python recommender.py
```

4. Enter a movie name from the dataset to receive genre-based recommendations.

## ✅ Sample Movies in Dataset

- The Matrix
- Inception
- Titanic
- The Notebook
- John Wick
- The Avengers
- Interstellar
- Pride & Prejudice
- Gladiator
- La La Land

## 📌 Note

Make sure `movies.csv` is in the same directory as `recommender.py` when running the script.

---

© 2025 | Movie Recommendation System
